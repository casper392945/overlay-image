{
	"data": {
		"_styles": {
			"padding-top": "(@paddingTop * 15px)",
			"padding-bottom": "(@paddingBottom * 15px)",
			"background-color": "@bgColor"
		},
		"_name": "content8",
		"_customHTML": "<section class=\"mbr-section content8\">\n\n    <mbr-parameters>\n    <!-- Block parameters controls (Blue \"Gear\" panel) -->\n        <input type=\"range\" inline=\"\" title=\"Top\" name=\"paddingTop\" min=\"0\" max=\"8\" step=\"1\" value=\"4\">\n        <input type=\"range\" inline=\"\" title=\"Bottom\" name=\"paddingBottom\" min=\"0\" max=\"8\" step=\"1\" value=\"4\">\n        <input type=\"color\" title=\"Backgroud Color\" name=\"bgColor\" value=\"#ffffff\">\n    <!-- End block parameters -->\n    </mbr-parameters>\n\n    <div class=\"container\">\n        <div class=\"media-container-row title\">\n            <div class=\"col-12 col-md-8\">\n                <div class=\"mbr-section-btn align-center\" mbr-buttons=\"\" mbr-theme-style=\"display-4\" data-toolbar=\"-mbrBtnMove\"><a class=\"btn btn-primary\" href=\"https://mobirise.co\" data-app-placeholder=\"Type Text\">USER BLOCK</a>\n                    <a class=\"btn btn-black-outline\" href=\"https://mobirise.co\" data-app-placeholder=\"Type Text\">PROJECT</a></div>\n            </div>\n        </div>\n    </div>\n</section>",
		"_customCSS": "",
		"_cid": "rdfgMuFw25",
		"_protectedParams": [],
		"_alwaysBottom": false,
		"_alwaysTop": false,
		"_global": false,
		"_noDrag": false,
		"_positionAbsolute": false,
		"_once": false,
		"_params": {
			"paddingTop": "4",
			"paddingBottom": "4",
			"bgColor": "#ffffff"
		},
		"_anchor": "content8-7"
	},
	"themeName": "mobirise4",
	"parent": "content8",
	"date": "2018-12-25 19.26:10",
	"blockName": "content8_7",
	"mediaPaths": "[]",
	"isUserblock": "true"
}